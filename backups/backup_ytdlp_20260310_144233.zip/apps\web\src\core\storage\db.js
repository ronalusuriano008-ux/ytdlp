export function getDB(){

  const data=localStorage.getItem("gmcn_db")
  if(!data) return {}

  return JSON.parse(data)

}

export function saveDB(db){

  localStorage.setItem("gmcn_db",JSON.stringify(db))

}