param(
    [string]$ProjectRoot = ".",
    [switch]$BackupFirst = $true
)

$ErrorActionPreference = "Stop"

function Write-Step($msg) {
    Write-Host "`n=== $msg ===" -ForegroundColor Cyan
}

function Ensure-Dir($path) {
    if (!(Test-Path $path)) {
        New-Item -ItemType Directory -Path $path | Out-Null
        Write-Host "Creado: $path" -ForegroundColor Green
    }
}

function Move-IfExists($from, $to) {
    if (Test-Path $from) {
        $parent = Split-Path $to -Parent
        Ensure-Dir $parent
        Move-Item -Path $from -Destination $to -Force
        Write-Host "Movido: $from -> $to" -ForegroundColor Yellow
    }
    else {
        Write-Host "No existe, se omite: $from" -ForegroundColor DarkGray
    }
}

function Copy-IfExists($from, $to) {
    if (Test-Path $from) {
        $parent = Split-Path $to -Parent
        Ensure-Dir $parent
        Copy-Item -Path $from -Destination $to -Force
        Write-Host "Copiado: $from -> $to" -ForegroundColor Magenta
    }
    else {
        Write-Host "No existe, se omite: $from" -ForegroundColor DarkGray
    }
}

function Ensure-File($path, $content = "") {
    $parent = Split-Path $path -Parent
    Ensure-Dir $parent
    if (!(Test-Path $path)) {
        Set-Content -Path $path -Value $content -Encoding UTF8
        Write-Host "Archivo creado: $path" -ForegroundColor Green
    }
}

$root = Resolve-Path $ProjectRoot
Set-Location $root

Write-Step "Proyecto detectado en: $root"

if ($BackupFirst) {
    Write-Step "Creando respaldo"
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupDir = Join-Path $root "backup-pre-migracion-$timestamp"
    Ensure-Dir $backupDir

    $itemsToBackup = @(
        "frontend",
        "node-api",
        "python-worker",
        "estructura-arbol.txt",
        "estructura-arbol-ant.txt"
    )

    foreach ($item in $itemsToBackup) {
        if (Test-Path $item) {
            Copy-Item $item -Destination $backupDir -Recurse -Force
            Write-Host "Respaldado: $item" -ForegroundColor Magenta
        }
    }
}

Write-Step "Creando nueva estructura"

$dirs = @(
    "apps/web/public",
    "apps/web/assets/styles",
    "apps/web/assets/styles/pages",
    "apps/web/assets/images",
    "apps/web/src/app",
    "apps/web/src/core/api",
    "apps/web/src/core/auth",
    "apps/web/src/core/storage",
    "apps/web/src/core/utils",
    "apps/web/src/features/search",
    "apps/web/src/features/player",
    "apps/web/src/features/download",
    "apps/web/src/features/websocket",
    "apps/web/src/features/voice",
    "apps/web/src/features/profile",
    "apps/web/src/features/downloads",
    "apps/web/src/features/history",
    "apps/web/src/features/favorites",
    "apps/web/src/pages/index",
    "apps/web/src/pages/musica",
    "apps/web/src/pages/perfil",
    "apps/web/src/pages/historial",
    "apps/web/src/pages/favoritos",
    "apps/web/src/pages/descargas",
    "apps/web/legacy/v1",

    "apps/api/src/config",
    "apps/api/src/routes",
    "apps/api/src/controllers",
    "apps/api/src/services",
    "apps/api/src/websocket",
    "apps/api/src/middlewares",
    "apps/api/src/utils",
    "apps/api/storage/uploads",
    "apps/api/storage/temp",

    "apps/worker/src/downloader",
    "apps/worker/src/models",
    "apps/worker/src/services",
    "apps/worker/src/utils",
    "apps/worker/storage/audio",
    "apps/worker/storage/videos",
    "apps/worker/storage/temp",
    "apps/worker/static",

    "data/users",
    "data/sessions",
    "data/history",
    "data/favorites",
    "data/downloads",

    "docs",
    "scripts",
    "packages/shared/constants",
    "packages/shared/schemas",
    "packages/shared/types"
)

foreach ($dir in $dirs) {
    Ensure-Dir $dir
}

Write-Step "Moviendo FRONTEND"

Move-IfExists "frontend/index.html" "apps/web/public/index.html"
Move-IfExists "frontend/musica.html" "apps/web/public/musica.html"
Move-IfExists "frontend/perfil.html" "apps/web/public/perfil.html"
Move-IfExists "frontend/historial.html" "apps/web/public/historial.html"
Move-IfExists "frontend/favoritos.html" "apps/web/public/favoritos.html"
Move-IfExists "frontend/descargas.html" "apps/web/public/descargas.html"
Move-IfExists "frontend/favicon.png" "apps/web/public/favicon.png"

Move-IfExists "frontend/styles.css" "apps/web/assets/styles/main.css"

Move-IfExists "frontend/auth.js" "apps/web/src/core/auth/auth.js"
Move-IfExists "frontend/session.js" "apps/web/src/core/auth/session.js"
Move-IfExists "frontend/db.js" "apps/web/src/core/storage/db.js"

Move-IfExists "frontend/js/main.js" "apps/web/src/app/main.js"
Move-IfExists "frontend/js/search.js" "apps/web/src/features/search/search.js"
Move-IfExists "frontend/js/voice.js" "apps/web/src/features/voice/voice.js"
Move-IfExists "frontend/js/websocket.js" "apps/web/src/features/websocket/websocket.js"

Move-IfExists "frontend/js/player/config.js" "apps/web/src/features/player/config.js"
Move-IfExists "frontend/js/player/loader.js" "apps/web/src/features/player/loader.js"
Move-IfExists "frontend/js/player/player.js" "apps/web/src/features/player/player.js"
Move-IfExists "frontend/js/player/prebuffer.js" "apps/web/src/features/player/prebuffer.js"
Move-IfExists "frontend/js/player/ui.js" "apps/web/src/features/player/playerUI.js"

Move-IfExists "frontend/js/download/download.js" "apps/web/src/features/download/download.js"
Move-IfExists "frontend/js/download/downloadAudio.js" "apps/web/src/features/download/downloadAudio.js"
Move-IfExists "frontend/js/download/downloadState.js" "apps/web/src/features/download/downloadState.js"
Move-IfExists "frontend/js/download/downloadStatus.js" "apps/web/src/features/download/downloadStatus.js"
Move-IfExists "frontend/js/download/downloadVideo.js" "apps/web/src/features/download/downloadVideo.js"

Move-IfExists "frontend/downloadsPage.js" "apps/web/src/features/downloads/downloadsPage.js"

Move-IfExists "frontend/musicPlayer.js" "apps/web/legacy/musicPlayer.js"
Move-IfExists "frontend/download.js" "apps/web/legacy/download.js"

Move-IfExists "frontend/js/v1/app.js" "apps/web/legacy/v1/app.js"
Move-IfExists "frontend/js/v1/download.js" "apps/web/legacy/v1/download.js"
Move-IfExists "frontend/js/v1/player.js" "apps/web/legacy/v1/player.js"

Write-Step "Moviendo API NODE"

Move-IfExists "node-api/server.js" "apps/api/src/server.js"
Move-IfExists "node-api/routes/search.js" "apps/api/src/routes/search.routes.js"
Move-IfExists "node-api/routes/metadata.js" "apps/api/src/routes/metadata.routes.js"
Move-IfExists "node-api/routes/stream.js" "apps/api/src/routes/stream.routes.js"
Move-IfExists "node-api/routes/download.js" "apps/api/src/routes/download.routes.js"

Move-IfExists "node-api/services/pythonClient.js" "apps/api/src/services/pythonClient.js"
Move-IfExists "node-api/services/queue.js" "apps/api/src/services/queue.js"

Move-IfExists "node-api/websocket/progress.js" "apps/api/src/websocket/progress.gateway.js"

Move-IfExists "node-api/uploads" "apps/api/storage/uploads"

Move-IfExists "node-api/package.json" "apps/api/package.json"
Move-IfExists "node-api/package-lock.json" "apps/api/package-lock.json"

if (Test-Path "node-api/download.js") {
    Move-IfExists "node-api/download.js" "apps/api/src/services/download.legacy.js"
}

Write-Step "Moviendo WORKER PYTHON"

Move-IfExists "python-worker/main.py" "apps/worker/src/main.py"

Move-IfExists "python-worker/downloader/ffmpeg_runner.py" "apps/worker/src/downloader/ffmpeg_runner.py"
Move-IfExists "python-worker/downloader/metadata.py" "apps/worker/src/downloader/metadata.py"
Move-IfExists "python-worker/downloader/ytdlp_runner.py" "apps/worker/src/downloader/ytdlp_runner.py"
Move-IfExists "python-worker/downloader/cookies.txt" "apps/worker/src/downloader/cookies.txt"

Move-IfExists "python-worker/models/job.py" "apps/worker/src/models/job.py"

Move-IfExists "python-worker/static/favicon.png" "apps/worker/static/favicon.png"

Move-IfExists "python-worker/storage/audio" "apps/worker/storage/audio"
Move-IfExists "python-worker/storage/videos" "apps/worker/storage/videos"

Move-IfExists "python-worker/requeriments.txt" "apps/worker/requirements.txt"
Move-IfExists "python-worker/cookies.txt" "apps/worker/cookies.txt"

if (Test-Path "python-worker/downloader/__pycache__") {
    Remove-Item "python-worker/downloader/__pycache__" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "Eliminado __pycache__" -ForegroundColor DarkYellow
}

Write-Step "Creando archivos base útiles"

Ensure-File "docs/architecture.md" @"
# Arquitectura del proyecto

- apps/web: frontend
- apps/api: backend Node/Express
- apps/worker: worker Python con yt-dlp y ffmpeg
- data: persistencia temporal en JSON
- packages/shared: constantes y esquemas compartidos
"@

Ensure-File "packages/shared/constants/routes.js" @"
export const ROUTES = {
  HOME: '/',
  MUSICA: '/musica.html',
  PERFIL: '/perfil.html',
  HISTORIAL: '/historial.html',
  FAVORITOS: '/favoritos.html',
  DESCARGAS: '/descargas.html'
};
"@

Ensure-File "packages/shared/constants/events.js" @"
export const EVENTS = {
  DOWNLOAD_PROGRESS: 'download:progress',
  DOWNLOAD_COMPLETE: 'download:complete',
  PLAYER_READY: 'player:ready'
};
"@

Ensure-File "packages/shared/constants/roles.js" @"
export const ROLES = {
  USER: 'user',
  ADMIN: 'admin'
};
"@

Ensure-File "README.md" @"
# ytdlp

Proyecto reorganizado en:
- apps/web
- apps/api
- apps/worker
- data
- docs
- packages/shared
"@

Write-Step "Intentando limpiar carpetas antiguas vacías"

$oldDirs = @(
    "frontend/js/download",
    "frontend/js/player",
    "frontend/js/v1",
    "frontend/js",
    "frontend",
    "node-api/routes",
    "node-api/services",
    "node-api/websocket",
    "node-api",
    "python-worker/downloader",
    "python-worker/models",
    "python-worker/static",
    "python-worker/storage",
    "python-worker"
)

foreach ($dir in $oldDirs) {
    if (Test-Path $dir) {
        try {
            $items = Get-ChildItem $dir -Force
            if ($items.Count -eq 0) {
                Remove-Item $dir -Force
                Write-Host "Carpeta vacía eliminada: $dir" -ForegroundColor DarkYellow
            }
            else {
                Write-Host "Carpeta no vacía, se conserva: $dir" -ForegroundColor DarkGray
            }
        }
        catch {
            Write-Host "No se pudo revisar/eliminar: $dir" -ForegroundColor Red
        }
    }
}

Write-Step "Migración finalizada"

Write-Host ""
Write-Host "Siguiente paso importante:" -ForegroundColor Cyan
Write-Host "Debes actualizar imports/rutas internas porque varios archivos cambiaron de ubicación." -ForegroundColor White
Write-Host ""
Write-Host "Ejemplos:" -ForegroundColor Cyan
Write-Host " - frontend/js/main.js -> apps/web/src/app/main.js"
Write-Host " - node-api/server.js -> apps/api/src/server.js"
Write-Host " - python-worker/main.py -> apps/worker/src/main.py"
Write-Host ""
Write-Host "Revisa especialmente:" -ForegroundColor Cyan
Write-Host " - imports relativos en JS"
Write-Host " - rutas de static/public"
Write-Host " - rutas a cookies.txt"
Write-Host " - rutas de storage/audio y storage/videos"
Write-Host " - referencias entre Node API y Python worker"